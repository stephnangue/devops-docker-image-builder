import io.jenkins.plugins.casc.ConfigurationAsCode

ConfigurationAsCode.get().configure()